package inclass02.poorna.com.group4_inclass12;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class ThreadActivity extends AppCompatActivity {
    EditText edThreadTitle;
    ListView mylist;
    FirebaseUser user;
    String name;
    FirebaseDatabase database;
    DatabaseReference dbref;
    private FirebaseAuth mAuth;
    Map<String, Object> threadMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thread);
        setTitle("Message Threads");
        mylist=findViewById(R.id.mylistview);
        edThreadTitle=findViewById(R.id.add_text);
        mAuth=FirebaseAuth.getInstance();
        database = FirebaseDatabase.getInstance();
        dbref=database.getReference("Threads");

        findViewById(R.id.add_btn).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(edThreadTitle.getText().length() != 0){
                    String title= edThreadTitle.getText().toString();
                    Log.d("demo","title="+title);
                    addThread(title);
                    edThreadTitle.setText("");

                }
                else{
                    Toast.makeText(ThreadActivity.this, "Please enter Thread name", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    public void addThread(String title)
    {
        ChatThread chatThread = new ChatThread();
        chatThread.setTitle(title);
        chatThread.setUid(user.getUid());


        threadMap=new HashMap<>();
        threadMap.put("threadlist",chatThread);
        dbref.push().setValue(threadMap);
    }

    @Override
    protected void onStart() {
        super.onStart();
        user=mAuth.getCurrentUser();
        name=user.getDisplayName();
        Log.d("demo","name="+name);

    }
}
