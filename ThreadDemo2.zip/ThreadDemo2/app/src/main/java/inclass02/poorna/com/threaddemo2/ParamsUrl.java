package inclass02.poorna.com.threaddemo2;

/**
 * Created by poorn on 2/12/2018.
 */

public class ParamsUrl {


}
