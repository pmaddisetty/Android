/**
 * Created by poorn on 2/26/2018.
 */

public class NewsItem {

}
