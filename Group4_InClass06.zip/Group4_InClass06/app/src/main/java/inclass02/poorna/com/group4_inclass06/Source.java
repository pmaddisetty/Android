package inclass02.poorna.com.group4_inclass06;

/**
 * Created by poorn on 2/19/2018.
 */

public class Source {
    String id;
    String name;

    @Override
    public String toString() {
        return "Source{" +
                "id='" + id + '\'' +
                ", name='" + name + '\'' +
                '}';
    }
}
